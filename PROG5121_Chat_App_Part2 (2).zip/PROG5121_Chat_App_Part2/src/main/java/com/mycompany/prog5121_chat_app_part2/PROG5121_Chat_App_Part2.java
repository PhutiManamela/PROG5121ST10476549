/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.prog5121_chat_app_part2;

/**
 *
 * @author RC_Student_lab
 */
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */




import org.json.simple.JSONObject;
import org.json.simple.JSONArray;
import java.util.*;
import javax.swing.JOptionPane;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;
import java.util.regex.Pattern;
/**
 *
 * @author RC_Student_lab
 */
public class PROG5121_Chat_App_Part2{
    Scanner scanner = new Scanner (System.in);
    //Variable to store 
      
    static String storedUsername;
    static String storedPassword;
      static JSONArray storedMessages = new 
            JSONArray();
   
    
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
            
    //User Registration
    System.out.println("====Registration====");
    
    //Username
    System.out.print("Enter Username(must contain '-' and be no longer than 5 characters ):");
    String username = input.nextLine();
    while (!isValidUsername (username)){
       System.out.print("Invalid username. Try again:");
       username = input.nextLine();
    }
    
    //Users Password
    System.out.print("Enter a strong password (min 8 characters,A-Z,a-z,numbers and symbol):");
    String password = input.nextLine();
    while (!isValidPassword(password)){
    System.out.print("Invalid Password. Try again:");
    password =input.nextLine();
    }
    
    //Cellphone number (Regex from ChatGPT)
    System.out.print("Enter your cellphone number here (e.g +2793434533):");
    String cell = input.nextLine();
    while (!isValidCell(cell)){
        System.out.print("Invalid number. Please Try again:");
        cell=input.nextLine();
    }
    
    //Storing Users Details
    storedUsername = username;
    storedPassword = password;
    System.out.println("\nRegistration successful!\n");
    
    //User Login
    int attempts = 0;
    boolean isLoggedIn = false;
    
       
     while(attempts < 3 && !isLoggedIn ) {
    System.out.println("===Login===");
    System.out.print("Enter username:");
    String loginUser = input.nextLine();
    System.out.print("Enter password:");
    String loginPass= input.nextLine();

    if (loginUser.equals(storedUsername)&&
            loginPass.equals(storedPassword) ){
        System.out.println("Login successful.welcome to QuickChat!");
       
        isLoggedIn = true;
    }else{
        attempts++;
        System.out.println("Login failed. Attempts left:" + (3- attempts));
       }
     }
     //Exit if login fails after 3 attempts
     if(!isLoggedIn){
        System.out.println("Too many failed attempts. Exiting. ");
        return;
     }
  
 
    //User chooses the number of messages to send 
    System.out.print("\nHow many messages do you want to send?");
    int maxMessages=Integer.parseInt(input.nextLine());
        int messagesSent = 0;
         
        
        //==Main Menu Loop==
        while(true){
              System.out.println("\n====Menu====");
              System.out.println("Option 1. Send Message");
              System.out.println("Option 2. Show Recent Messages");
              System.out.println("Option 3. Quit");
              System.out.println("Select an option");
              String option = input.nextLine();
              
              switch(option){
                  case "1" -> {
                      //check if message is reached
                      if (messagesSent >= maxMessages){
                          System.out.println("You have reached the message limit");
                          break;
                      }
                      System.out.print("Enter recipient name: ");
                      String recipient = input.nextLine();
                      System.out.print("Enter message: ");
                      String messageText = input.nextLine();
                      
                      Message msg= new Message(recipient,messageText);
                      if (msg.checkMessage()){
                          storedMessages.add(msg.toJSON());
                          saveMessagesToFile("messages.json");
                          System.out.println("Message sent and saved");
                          messagesSent++;
                      }else{
                          System.out.println("Invalid message. Must be non-empty and <= 250 characters.");
                      
                      }
                }
                      
                      case"2" -> {
                          //show recent messages
                          System.out.println("===Recent Messages===");
                          for (Object obj : storedMessages){
                              JSONObject msgJson = (JSONObject)obj;
                              System.out.println("To:"+ msgJson.get("recipient"));
                              System.out.println("Message:"+ msgJson.get("message"));
                              System.out.println("Hash:"+ msgJson.get("hash"));
                              System.out.println("ID:"+ msgJson.get("messageID"));
                              
                              System.out.println("Coming soon...");
                          }
                }
                     case "3" -> {
                         //exiting the app
                         System.out.println("Exiting QuickChat. Goodbye!!!");
                         return;
                }
             
             default -> System.out.println("Invalid option. Try again.");
              }
        }
     }
   
       
    //Validation methods
    public static boolean isValidUsername(String username){
        return username.contains("_")&&
                username.length()<=5;
    }
    public static boolean isValidPassword(String password){
        //Password must contain uppercase,lowercase,digit,special character and be 8 characters long
        String pattern="^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@#$%^&+=!]).{8,}$";
        return password.length()>=8 &&
                Pattern.matches(pattern,password);
    }
    
    public static boolean isValidCell(String cell){
        //Attributed to ChatGPT for providing regex for south african numbers(+27 and 9 digits)
        String pattern="\\+27\\d{9}$";
        return Pattern.matches(pattern, cell);
    }
          
      public static void saveMessagesToFile(String filename)
      {
          try(FileWriter file = new FileWriter(filename)){
              file.write(storedMessages.toJSONString());
          }catch(IOException e) {
              System.out.println("Error saving messages:" + e.getMessage());
          }
      }
}
          
              
                          
     
              

