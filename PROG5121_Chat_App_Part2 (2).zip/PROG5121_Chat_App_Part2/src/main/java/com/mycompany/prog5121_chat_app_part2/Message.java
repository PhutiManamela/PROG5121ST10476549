/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prog5121_chat_app_part2;

/**
 *
 * @author RC_Student_lab
 */

import org.json.simple.JSONObject;
import java.util.UUID;
class Message {

    private String recipient;
    private String messageText;
    private String messageID;
    private String hash;

    public Message(String recipient, String messageText) {
        this.recipient= recipient;
        this.messageText = messageText;
        this.hash = Integer.toHexString((recipient + messageText).hashCode());
        this.messageID = UUID.randomUUID().toString();
       
    }
    public boolean checkMessage(){
        return messageText != null && ! messageText.isEmpty()
                && messageText.length()<=250;
    }
    public JSONObject toJSON(){
        JSONObject obj = new JSONObject();
        obj.put("recipient", recipient);
         obj.put("message", messageText);
          obj.put("messageID", messageID);
        obj.put("hash", hash);
        return obj;
    }
    
}
    
       
     
    


   