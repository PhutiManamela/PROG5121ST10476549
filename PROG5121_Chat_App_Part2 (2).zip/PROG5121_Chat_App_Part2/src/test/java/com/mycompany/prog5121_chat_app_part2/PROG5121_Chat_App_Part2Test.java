/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.prog5121_chat_app_part2;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author RC_Student_lab
 */
public class PROG5121_Chat_App_Part2Test {
    



    @Test
    public void testValidMessage() {
        Message msg = new Message("+27834557896", "Did you get the cake ?");
        assertTrue(msg.checkMessage());
    }

    @Test
    public void testEmptyMessage() {
        Message msg = new Message("+27838884567", "");
        assertFalse(msg.checkMessage());
    }

   

    @Test
    public void testLongMessage() {
        String longText = "Where are you? You are late! I have asked you to be on time".repeat(251);
        Message msg = new Message("+27838884567", longText);
        assertFalse(msg.checkMessage());
    }

    @Test
    public void testMessageToJsonContainsFields() {
        Message msg = new Message("+27838884567", "Test message");
        assertNotNull(msg.toJSON().get("recipient"));
        assertNotNull(msg.toJSON().get("message"));
        assertNotNull(msg.toJSON().get("hash"));
        assertNotNull(msg.toJSON().get("messageID"));
    }

    @Test
    public void testHashGeneration() {
        Message msg = new Message("Test", "HashMe123");
        String expectedHash = Integer.toHexString("TestHashMe123".hashCode());
        assertEquals(expectedHash, msg.toJSON().get("hash"));
    }
}