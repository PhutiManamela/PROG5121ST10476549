/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.prog5121_chat_app;


import java.util.Scanner;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author RC_Student_lab
 */
public class PROG5121_Chat_AppTest {
    
    public PROG5121_Chat_AppTest() {
    }

    

    @org.junit.jupiter.api.BeforeEach
    public void setUp() throws Exception {
    }

    @org.junit.jupiter.api.AfterEach
    public void tearDown() throws Exception {
    }
    
   
    
    @BeforeEach
    public void initScanner() {
        Scanner scanner= new Scanner(System.in);
    }
    
    
    @Test
    public void Setup() {
    }

    /**
     * Test of main method, of class PROG5121_Chat_App.
     */
    @org.junit.jupiter.api.Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        PROG5121_Chat_App.main(args);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of isValidUsername method, of class PROG5121_Chat_App.
     */
    @org.junit.jupiter.api.Test
    public void testIsValidUsername() {
        System.out.println("isValidUsername");
        String username = "";
        boolean expResult = false;
        boolean result = PROG5121_Chat_App.isValidUsername(username);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of isValidPassword method, of class PROG5121_Chat_App.
     */
    @org.junit.jupiter.api.Test
    public void testIsValidPassword() {
        System.out.println("isValidPassword");
        String password = "";
        boolean expResult = false;
        boolean result = PROG5121_Chat_App.isValidPassword(password);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of isValidCell method, of class PROG5121_Chat_App.
     */
    @org.junit.jupiter.api.Test
    public void testIsValidCell() {
        System.out.println("isValidCell");
        String cell = "";
        boolean expResult = false;
        boolean result = PROG5121_Chat_App.isValidCell(cell);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
